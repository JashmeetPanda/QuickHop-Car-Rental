package com.quickhop.DTO;

import java.time.LocalDate;

public class BookingRequest {
    private LocalDate startDate;
    private LocalDate endDate;
    private String username; // Store the username instead of the User object

    // Getters and Setters
    public LocalDate getStartDate() { 
        return startDate; 
    }

    public void setStartDate(LocalDate startDate) { 
        this.startDate = startDate; 
    }

    public LocalDate getEndDate() { 
        return endDate; 
    }

    public void setEndDate(LocalDate endDate) { 
        this.endDate = endDate; 
    }

    public String getUsername() { // Return username instead of User object
        return username; 
    }

    public void setUsername(String username) { 
        this.username = username; 
    }
}
