package com.quickhop.controller;

import com.quickhop.entity.Booking;
import com.quickhop.entity.Car;
import com.quickhop.entity.CarStatus;
import com.quickhop.entity.User;
import com.quickhop.repository.CarRepository;
import com.quickhop.repository.UserRepository;
import com.quickhop.service.BookingService;
import com.quickhop.service.UserService;
import com.razorpay.Order;
import com.razorpay.RazorpayClient;

import jakarta.servlet.http.HttpSession;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.*;

/**
 * Controller for managing user actions, car operations, and payment processing.
 */
@Controller
@RequestMapping("/")
public class MyController {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private CarRepository carRepository;
    
    @Autowired
    private UserService userService;
    
    
    @Autowired
    private BookingService bookingService;

    

    // Show registration page
    @GetMapping("/register")
    public String showRegisterPage() {
        return "register";
    }

    // Handle registration form submission
    @PostMapping("/register")
    public String registerUser(@ModelAttribute User user, Model model) {
        int rows = userRepository.saveUser(user);
        if (rows > 0) {
            return "redirect:/login";
        } else {
            model.addAttribute("error", "Registration failed! Please try again.");
            return "register";
        }
    }

    // Show login page
    @GetMapping("/login")
    public String showLoginPage() {
        return "login";
    }

    // Handle login form submission
    @PostMapping("/login")
    public String loginUser(@RequestParam String username, 
                            @RequestParam String password, 
                            HttpSession session, 
                            Model model) {
        
        // Validate the user credentials (username and password)
        boolean isValidUser = userRepository.validateUser(username, password);

        if (isValidUser) {
            // Fetch the user from the database based on username
            Optional<User> user = userRepository.findByUsername(username);

            // If user is found, store the username in the session
            user.ifPresent(value -> {
                session.setAttribute("username", value.getUsername());
            });

            // Redirect to the dashboard after successful login
            return "redirect:/dashboard";
        } else {
            // If login is invalid, add an error message and return to the login page
            model.addAttribute("error", "Invalid username or password!");
            return "login";
        }
    }


    // Show forgot password page
    @GetMapping("/forgot-password")
    public String showForgotPasswordPage(Model model) {
        model.addAttribute("step2", false);
        return "forgot-password";
    }

    // Handle forgot password step 1: Validate username and email
    @PostMapping("/forgot-password/validate")
    public String validateForgotPassword(@RequestParam String username, @RequestParam String email, Model model) {
        Optional<User> user = userRepository.findByUsernameAndEmail(username, email);
        if (user.isPresent()) {
            model.addAttribute("step2", true);
            model.addAttribute("username", username);
        } else {
            model.addAttribute("error", "Invalid username or email!");
            model.addAttribute("step2", false);
        }
        return "forgot-password";
    }

    // Handle forgot password step 2: Reset password
    @PostMapping("/forgot-password/reset")
    public String resetPassword(@RequestParam String username, @RequestParam String newPassword, @RequestParam String confirmPassword, Model model) {
        if (!newPassword.equals(confirmPassword)) {
            model.addAttribute("error", "Passwords do not match!");
            model.addAttribute("step2", true);
            model.addAttribute("username", username);
            return "forgot-password";
        }

        if (newPassword.length() < 3) {
            model.addAttribute("error", "Password must be at least 8 characters long.");
            model.addAttribute("step2", true);
            model.addAttribute("username", username);
            return "forgot-password";
        }

        boolean isUpdated = userRepository.updatePassword(username, newPassword);
        if (isUpdated) {
            return "redirect:/login";
        } else {
            model.addAttribute("error", "Failed to reset password! Please try again.");
            model.addAttribute("step2", true);
            model.addAttribute("username", username);
            return "forgot-password";
        }
    }

    // Show dashboard page
    @GetMapping("/dashboard")
    public String showDashboard(@RequestParam(required = false) String username, 
                                HttpSession session, 
                                Model model) {
        // Retrieve the username from the session
        String loggedInUsername = (String) session.getAttribute("username");

        // If the username is not found in session, redirect to the login page
        if (loggedInUsername == null || loggedInUsername.isEmpty()) {
            return "redirect:/login";
        }

        // Add the logged-in username to the model
        model.addAttribute("username", loggedInUsername);

        // If the user has entered a username, verify it against the logged-in username
        if (username != null && !username.isEmpty()) {
            if (!username.equals(loggedInUsername)) {
                // Add an error flag if the usernames don't match
                model.addAttribute("usernameError", true);
            } else {
                // If the username matches, no error is needed
                model.addAttribute("usernameError", false);
            }
        }

        // Return the dashboard page
        return "dashboard";
    }




    
    

    // Logout the user
    @GetMapping("/logout")
    public String logoutUser(HttpSession session) {
        session.invalidate();
        return "redirect:/login";
    }

    // Search cars with filters
    @GetMapping("/search")
    public String showSearchPage(@RequestParam(required = false) String make,
                                 @RequestParam(required = false) String model,
                                 @RequestParam(required = false) String price,
                                 Model modelAttribute) {
        Integer priceInt = null;
        if (price != null && !price.isEmpty()) {
            try {
                priceInt = Integer.parseInt(price);
            } catch (NumberFormatException e) {
                modelAttribute.addAttribute("error", "Invalid price format");
                return "search";
            }
        }

        List<Car> results = carRepository.searchCars(make, model, priceInt, CarStatus.AVAILABLE);
        modelAttribute.addAttribute("results", results);
        modelAttribute.addAttribute("make", make);
        modelAttribute.addAttribute("model", model);
        modelAttribute.addAttribute("price", price);

        return "search";
    }

    // Book a car
    @PostMapping("/book/{id}")
    public String bookCar(@PathVariable Long id, Model model) {
        Optional<Car> optionalCar = carRepository.findById(id);
        if (optionalCar.isPresent()) {
            Car car = optionalCar.get();
            if (car.getStatus() == CarStatus.AVAILABLE) {
                car.setStatus(CarStatus.RENTED);
                carRepository.save(car);
                model.addAttribute("message", "Car booked successfully!");
                return "dashboard";
            } else {
                model.addAttribute("error", "Car is not available for booking.");
                return "dashboard";
            }
        } else {
            model.addAttribute("error", "Car not found.");
            return "dashboard";
        }
    }

    // Create Razorpay order
    @PostMapping("/create-order")
    public ResponseEntity<Map<String, Object>> createOrder(@RequestBody Map<String, Object> request) {
        try {
            String carId = (String) request.get("carId");
            int amount = (int) request.get("amount");

            RazorpayClient client = new RazorpayClient("YOUR_KEY_ID", "YOUR_KEY_SECRET");

            JSONObject orderRequest = new JSONObject();
            orderRequest.put("amount", amount);
            orderRequest.put("currency", "INR");
            orderRequest.put("receipt", "order_receipt_" + carId);

            Order order = client.orders.create(orderRequest);

            return ResponseEntity.ok(Map.of("order_id", order.get("id")));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(Map.of("message", e.getMessage()));
        }
    }

    // Show payment page
    @GetMapping("/payment/{orderId}")
    public String showPaymentPage(@PathVariable String orderId, Model model) {
        model.addAttribute("orderId", orderId);
        return "payment";
    }

    // Show admin dashboard
    @GetMapping("/a_dashboard")
    public String showAdminDashboard() {
        return "a_dashboard";
    }

    // Show cars page
    @GetMapping("/cars")
    public String showCars() {
        return "cars";
    }

    // Show manage cars page
    @GetMapping("/manage_cars")
    public String showManageCars() {
        return "manage_cars";
    }
    
    @GetMapping("/delete")
    public String deleteCars() {
        return "delete";
    }
    
    @GetMapping("/update")
    public String updateCar() {
        return "update";
    }
    
    @GetMapping("/a_search")
    public String searchCar() {
        return "a_search";
    }
    
    @GetMapping("/booking")
    public String getBookings(@RequestParam(required = false) String username, 
                              HttpSession session, 
                              Model model) {
        List<Booking> bookings = new ArrayList<>();

        // Get the username from the session (the logged-in user's username)
        String loggedInUsername = (String) session.getAttribute("username");

        // Check if the username entered matches the logged-in user
        if (username != null && !username.isEmpty() && username.equals(loggedInUsername)) {
            // Get the userId by the username
            Optional<User> userOptional = userService.findByUsername(username);
            
            if (userOptional.isPresent()) {
                Long userId = userOptional.get().getId();
                bookings = bookingService.getBookingsByUserId(userId);
            }
        }

        model.addAttribute("bookings", bookings);
        return "booking";
    }

}
