package com.quickhop.controller;

import com.quickhop.entity.User;
import com.quickhop.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import jakarta.servlet.http.HttpSession;


@RestController
@RequestMapping("/api")
public class UserController {

    @Autowired
    private UserRepository userRepository;

    // Registration endpoint
    
    @PostMapping("/register")
    public ResponseEntity<String> registerUser(@RequestBody User user) {
        // Validate user fields, e.g. check if the username already exists
        int rows = userRepository.saveUser(user);

        if (rows > 0) {
            return ResponseEntity.ok("Registration successful!");
        } else {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Registration failed. Please try again.");
        }
    }
    

    // Dashboard endpoint (secured, requires session check)
    @GetMapping("/dashboard")
    public ResponseEntity<String> showDashboard(HttpSession session) {
        // Check if the user is logged in
        if (session.getAttribute("user") == null) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("You must log in to access the dashboard.");
        }
        return ResponseEntity.ok("Welcome to the Dashboard!"); // Adjust as per your dashboard content
    }

    // Logout endpoint
    @PostMapping("/logout")
    public ResponseEntity<String> logout(HttpSession session) {
        // Invalidate the session
        session.invalidate();
        return ResponseEntity.ok("Logout successful. You are now redirected to the login page.");
    }
    
    
    
}
