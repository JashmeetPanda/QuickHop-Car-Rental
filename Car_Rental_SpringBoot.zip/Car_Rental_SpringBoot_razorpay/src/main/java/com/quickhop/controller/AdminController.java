package com.quickhop.controller;

import com.quickhop.entity.Car;
import com.quickhop.service.AdminService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/admin")
public class AdminController {
	
	

    @Autowired
    private AdminService adminService;

    // Add a new car
    @PostMapping("/addCar")
    public ResponseEntity<String> addCar(@RequestBody Car car) {
        try {
            // Validate input
            if (car.getMake() == null || car.getMake().isEmpty()) {
                return ResponseEntity.badRequest().body("Car make is required.");
            }
            if (car.getModel() == null || car.getModel().isEmpty()) {
                return ResponseEntity.badRequest().body("Car model is required.");
            }
            if (car.getPrice() == null || car.getPrice() <= 0) {
                return ResponseEntity.badRequest().body("Car price must be positive.");
            }
            if (car.getStatus() == null) {
                return ResponseEntity.badRequest().body("Car status is required.");
            }

            // Save the car
            adminService.addCar(car);
            return ResponseEntity.ok("Car added successfully!");
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                                 .body("An internal error occurred.");
        }
    }
    

 // In your Spring Boot Controller
    @PutMapping("/updateCar/{carId}")
    public ResponseEntity<Map<String, String>> updateCar(@PathVariable Long carId, @RequestBody Car carData) {
        try {
            // Call service to update car details
            String result = adminService.updateCar(carId, carData);
            
            // Return a proper JSON response
            Map<String, String> response = new HashMap<>();
            response.put("message", result); // Include success message or failure message
            return ResponseEntity.ok(response); // Send JSON response
        } catch (Exception e) {
            // Handle error and send failure message
            Map<String, String> errorResponse = new HashMap<>();
            errorResponse.put("message", "Error: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(errorResponse);
        }
    }

    @DeleteMapping("/deleteCar/{carId}")
    public ResponseEntity<Map<String, String>> deleteCar(@PathVariable Long carId) {
        try {
            String result = adminService.deleteCar(carId);
            
            // Return a JSON response with a message key
            Map<String, String> response = new HashMap<>();
            response.put("message", result);
            
            return ResponseEntity.ok(response);  // Send the response as JSON
        } catch (IllegalArgumentException e) {
            Map<String, String> response = new HashMap<>();
            response.put("message", "Car not found with ID: " + carId);
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
        } catch (Exception e) {
            Map<String, String> response = new HashMap<>();
            response.put("message", "Failed to delete car. Error: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }


    // Get all cars
    @GetMapping("/getAllCars")
    public ResponseEntity<List<Car>> getAllCars() {
        try {
            List<Car> cars = adminService.getAllCars();
            return ResponseEntity.ok(cars);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
        }
    }

    // Get a car by ID
    @GetMapping("/getCar/{carId}")
    public ResponseEntity<Car> getCar(@PathVariable Long carId) {
        try {
            Car car = adminService.getCarById(carId);
            return ResponseEntity.ok(car);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
        }
    }
    

}
