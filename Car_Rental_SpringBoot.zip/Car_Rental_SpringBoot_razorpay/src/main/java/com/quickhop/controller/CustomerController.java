package com.quickhop.controller;

import com.quickhop.DTO.BookingRequest;
import com.quickhop.entity.Car;
import com.quickhop.entity.User;
import com.quickhop.service.CustomerService;
import com.quickhop.service.UserService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api") // Standardized API path for frontend
public class CustomerController {

    @Autowired
    private CustomerService customerService;
    @Autowired
    private UserService userService;
    

    /**
     * Get a list of all available cars.
     * @return List of available cars.
     */
    @GetMapping("/cars")
    public List<Car> getAvailableCars() {
        return customerService.getAvailableCars();
    }

    /**
     * Get details of a car by its ID.
     * @param carId the ID of the car.
     * @return the car details.
     */
    @GetMapping("/cars/{carId}")
    public Car getCarById(@PathVariable Long carId) {
        return customerService.getCarById(carId);
    }

    /**
     * Rent a car by its ID.
     * @param carId the ID of the car to be rented.
     * @return a message indicating the rental status.
     */
    @PostMapping("/cars/rent/{carId}")
    public ResponseEntity<String> rentCar(
            @PathVariable Long carId,
            @RequestBody BookingRequest bookingRequest) {
        try {
            // Log the incoming username and the entire booking request for debugging purposes
            System.out.println("Booking request for user: " + bookingRequest.getUsername());
            System.out.println("Car ID: " + carId);
            System.out.println("Booking start date: " + bookingRequest.getStartDate());
            System.out.println("Booking end date: " + bookingRequest.getEndDate());

            // Fetch user by username from the request body
            Optional<User> userOptional = userService.findByUsername(bookingRequest.getUsername());

            // Log the result of the user search
            if (userOptional.isEmpty()) {
                System.out.println("User not found with username: " + bookingRequest.getUsername());
                return ResponseEntity.status(HttpStatus.NOT_FOUND)
                                     .body("User not found");
            }

            User user = userOptional.get();  // Retrieve the User object from Optional
            System.out.println("User found: " + user.getUsername() + " with ID: " + user.getId());

            // Now we call the service to rent the car, passing the user ID
            String result = customerService.rentCar(carId, bookingRequest.getStartDate(),
                    bookingRequest.getEndDate(), user.getId());  // Pass the user ID for booking

            // Return the result from the service
            return ResponseEntity.ok(result);

        } catch (Exception e) {
            // Log the exception stack trace for debugging
            System.out.println("Error during car rental process: " + e.getMessage());
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                                 .body("Error booking the car: " + e.getMessage());
        }
    }

}
