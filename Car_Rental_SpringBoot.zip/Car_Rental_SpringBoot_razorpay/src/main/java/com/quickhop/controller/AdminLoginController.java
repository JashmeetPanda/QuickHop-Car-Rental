package com.quickhop.controller;


import com.quickhop.service.AdminService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class AdminLoginController {

    @Autowired
    private AdminService adminService;

    @GetMapping("/a_login")
    public String showLoginPage() {
        return "a_login"; // Display login form
    }

    @PostMapping("/a_login")
    public String login(@RequestParam String username, @RequestParam String password, Model model) {
        if (adminService.authenticate(username, password)) {
            return "redirect:/a_dashboard"; // Redirect to the dashboard if authentication is successful
        } else {
            model.addAttribute("error", "Invalid credentials");
            return "a_login"; // Stay on the login page with an error message
        }
    }
    
    
}
