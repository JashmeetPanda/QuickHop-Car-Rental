package com.quickhop.service;

import com.quickhop.entity.Admin;
import com.quickhop.entity.Car;
import com.quickhop.repository.AdminRepository;
import com.quickhop.repository.CarRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class AdminService {
	
	 @Autowired
	private AdminRepository adminRepository;

	public boolean authenticate(String username, String password) {
	   Optional<Admin> admin = adminRepository.findByUsername(username);
	   return admin.isPresent() && admin.get().getPassword().equals(password); // Simple password matching
	}

    @Autowired
    private CarRepository carRepository;

    // Add a new car
    public void addCar(Car car) {
        carRepository.save(car);
    }

    // Update an existing car's details
    public String updateCar(Long carId, Car updatedCar) {
        Optional<Car> existingCarOpt = carRepository.findById(carId);
        if (existingCarOpt.isPresent()) {
            Car existingCar = existingCarOpt.get();
            existingCar.setMake(updatedCar.getMake());
            existingCar.setModel(updatedCar.getModel());
            existingCar.setPrice(updatedCar.getPrice());
            carRepository.save(existingCar);
            return "Car updated successfully!";
        }
        return "Car not found!";
    }

    // Delete a car by ID
    public String deleteCar(Long carId) {
        if (carRepository.existsById(carId)) {
            carRepository.deleteById(carId);
            return "Car deleted successfully!";
        }
        return "Car not found!";
    }

    // Get a list of all cars
    public List<Car> getAllCars() {
        return carRepository.findAll();
    }

    // Get details of a car by ID
    public Car getCarById(Long carId) {
        return carRepository.findById(carId).orElse(null);
    }
}
