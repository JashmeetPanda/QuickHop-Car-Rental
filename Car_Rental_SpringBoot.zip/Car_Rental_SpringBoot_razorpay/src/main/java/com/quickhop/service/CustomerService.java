package com.quickhop.service;

import com.quickhop.entity.Booking;
import com.quickhop.entity.Car;
import com.quickhop.entity.CarStatus;
import com.quickhop.entity.User;
import com.quickhop.repository.BookingRepository;
import com.quickhop.repository.CarRepository;
import com.quickhop.repository.UserRepository;

import jakarta.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class CustomerService {

    @Autowired
    private CarRepository carRepository;
    
    @Autowired
    private UserRepository userRepository;

    @Autowired
    private BookingRepository bookingRepository;
    /**
     * Get a list of all available cars.
     * @return List of available cars.
     */
    public List<Car> getAvailableCars() {
        return carRepository.findByStatus(CarStatus.AVAILABLE);  // Use the correct enum
    }

    /**
     * Get details of a car by its ID.
     * @param carId the ID of the car.
     * @return the car details.
     */
    public Car getCarById(Long carId) {
        Optional<Car> car = carRepository.findById(carId);
        return car.orElse(null);
    }

    /**
     * Rent a car by its ID.
     * @param carId the ID of the car to be rented.
     * @return a message indicating the rental status.
     */
    @Transactional
    public String rentCar(Long carId, LocalDate startDate, LocalDate endDate, Long userId) {
        // Fetch the car based on the carId
        Optional<Car> carOptional = carRepository.findById(carId);

        if (carOptional.isPresent()) {
            Car car = carOptional.get();
            System.out.println("Found car: " + car.getId() + " with status: " + car.getStatus());  // Log the car details

            // Ensure the car is available for rent
            if (car.getStatus() == CarStatus.AVAILABLE) {
            	System.out.println("Car is available, updating status to RENTED.");
                // Fetch the user by userId
            	System.out.println("Searching for user with ID: " + userId); 
                Optional<User> userOptional = userRepository.findByUserId(userId);
                if (userOptional.isPresent()) {
                	
                    User user = userOptional.get();
                    System.out.println("User found: " + userOptional.get().getUsername());

                    // Update car status to 'RENTED'
                    car.setStatus(CarStatus.RENTED);
                    System.out.println("Updating car status to RENTED for car ID: " + carId);

                    // Save the updated car status in the database
                    carRepository.save(car);

                    // Create and save the booking
                    Booking booking = new Booking();
                    booking.setCar(car);
                    booking.setBookingTime(LocalDateTime.now());
                    booking.setStartDate(startDate);
                    booking.setEndDate(endDate);
                    booking.setUser(user);

                    bookingRepository.save(booking);

                    // Return success message
                    return "Car rented successfully!";
                } else {
                    // Return message if the user is not found
                    return "User not found!";
                }
            } else {
                // Return message if the car is not available
                return "Car is not available for rent!";
            }
        } else {
            // Return message if the car is not found
            return "Car not found!";
        }
    }


    



    /**
     * Search cars based on make, model, and price.
     * @param make the make of the car (optional).
     * @param model the model of the car (optional).
     * @param price the price filter (optional).
     * @return List of cars matching the search criteria.
     */
    public List<Car> searchCars(String make, String model, Integer price) {
        if (make != null && !make.isEmpty() && model != null && !model.isEmpty() && price != null) {
            return carRepository.findByMakeAndModelAndPriceLessThan(make, model, price);
        } else if (make != null && !make.isEmpty()) {
            return carRepository.findByMake(make);  // Search only by make
        } else if (model != null && !model.isEmpty()) {
            return carRepository.findByModel(model);  // Search only by model
        } else if (price != null) {
            return carRepository.findByPriceLessThan(price);  // Search only by price
        } else {
            return carRepository.findByStatus(CarStatus.AVAILABLE);  // Return all available cars if no filters are provided
        }
    }

    public Car getCarDetailsById(Long carId) {
        return carRepository.findById(carId)
                             .orElseThrow(() -> new RuntimeException("Car not found with ID: " + carId));
    }
    
    
}
