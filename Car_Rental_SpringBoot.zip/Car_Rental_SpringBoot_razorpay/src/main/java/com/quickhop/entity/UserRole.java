package com.quickhop.entity;

public enum UserRole {
    ADMIN,
    CUSTOMER
}
