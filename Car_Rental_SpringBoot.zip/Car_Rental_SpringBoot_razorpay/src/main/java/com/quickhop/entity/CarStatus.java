package com.quickhop.entity;

public enum CarStatus {
	AVAILABLE,
    RENTED
}
