package com.quickhop.repository;

import java.util.Optional;

import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.quickhop.entity.User;

@Repository
public class UserRepository {

    private final JdbcTemplate jdbcTemplate;

    public UserRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    // Save a new user
    public int saveUser(User user) {
        String sql = "INSERT INTO users (username, email, password) VALUES (?, ?, ?)";
        return jdbcTemplate.update(sql, user.getUsername(), user.getEmail(), user.getPassword());
    }

    // Find user by username
    public Optional<User> findByUsername(String username) {
        // Ensure the username is being passed correctly
        System.out.println("Executing query for username: " + username);

        // Define the SQL query
        String sql = "SELECT * FROM users WHERE username = ?";

        try {
            // Attempt to retrieve the user using the query
            User user = jdbcTemplate.queryForObject(sql, new Object[]{username}, new UserRowMapper());

            // Log if a user is found
            if (user != null) {
                System.out.println("User found: " + user.getUsername() + " with ID: " + user.getId());
            }

            return Optional.ofNullable(user);
        } catch (EmptyResultDataAccessException e) {
            // Log if no user is found
            System.out.println("No user found for username: " + username);
            return Optional.empty();
        } catch (Exception e) {
            // Log unexpected exceptions
            System.out.println("Error during user query for username: " + username);
            e.printStackTrace();
            return Optional.empty();
        }
    }



    // Validate user by username and password
    public boolean validateUser(String username, String password) {
        String sql = "SELECT COUNT(*) FROM users WHERE username = ? AND password = ?";
        int count = jdbcTemplate.queryForObject(sql, new Object[]{username, password}, Integer.class);
        return count > 0;
    }

    // Find user by username and email
    public Optional<User> findByUsernameAndEmail(String username, String email) {
        String sql = "SELECT * FROM users WHERE username = ? AND email = ?";

        try {
            User user = jdbcTemplate.queryForObject(sql, new Object[]{username, email}, new UserRowMapper());
            return Optional.ofNullable(user);
        } catch (EmptyResultDataAccessException e) {
            return Optional.empty();
        }
    }

    // Find user by username, email, and password
    public Optional<User> findByUsernameAndEmailAndPassword(String username, String email, String password) {
        String sql = "SELECT * FROM users WHERE username = ? AND email = ? AND password = ?";

        try {
            User user = jdbcTemplate.queryForObject(sql, new Object[]{username, email, password}, new UserRowMapper());
            return Optional.ofNullable(user);
        } catch (EmptyResultDataAccessException e) {
            return Optional.empty();
        }
    }

    // Update user password
    public boolean updatePassword(String username, String newPassword) {
        String sql = "UPDATE users SET password = ? WHERE username = ?";
        int rowsAffected = jdbcTemplate.update(sql, newPassword, username);
        return rowsAffected > 0;
    }
    
    public Optional<User> findByUserId(Long userId) {
        String sql = "SELECT * FROM users WHERE id = ?";

        try {
            User user = jdbcTemplate.queryForObject(sql, new Object[]{userId}, new UserRowMapper());
            return Optional.ofNullable(user);
        } catch (EmptyResultDataAccessException e) {
            return Optional.empty();
        } catch (Exception e) {
            e.printStackTrace();
            return Optional.empty();
        }
    }
}
