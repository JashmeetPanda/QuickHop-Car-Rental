package com.quickhop.repository;

import com.quickhop.entity.Car;
import com.quickhop.entity.CarStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.ui.Model;

import java.util.List;
import java.util.Optional;

public interface CarRepository extends JpaRepository<Car, Long> {

    // Find cars by status (Available, Rented, etc.)
    

    // Search cars by make
    List<Car> findByMake(String make);

    // Search cars by model
    List<Car> findByModel(String model);

    // Search cars by price less than a given value
    List<Car> findByPriceLessThan(Integer price);

    // Search cars by make, model, and price
    List<Car> findByMakeAndModelAndPriceLessThan(String make, String model, Integer price);

    Optional<Car> findById(Long id);

    // Custom search query with dynamic parameters
    List<Car> findByStatus(CarStatus status);

    // Custom search query with dynamic parameters, including status
    @Query("SELECT c FROM Car c WHERE " +
           "(:make IS NULL OR c.make LIKE %:make%) AND " +
           "(:model IS NULL OR c.model LIKE %:model%) AND " +
           "(:price IS NULL OR c.price <= :price) AND " +
           "(:status IS NULL OR c.status = :status)")
    List<Car> searchCars(@Param("make") String make,
                         @Param("model") String model,
                         @Param("price") Integer price,
                         @Param("status") CarStatus status);

	
}
