package com.quickhop.repository;

import com.quickhop.entity.Booking;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.time.LocalDate;
import java.time.LocalDateTime;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.quickhop.entity.Booking;
import com.quickhop.entity.Car;
import com.quickhop.entity.User;

import jakarta.transaction.Transactional;

public interface BookingRepository extends JpaRepository<Booking, Long> {
    @Transactional
    @Modifying
    @Query("INSERT INTO Booking (car, bookingTime, startDate, endDate, user) " +
           "VALUES (:car, :bookingTime, :startDate, :endDate, :user)")
    void save(
        @Param("car") Car car,
        @Param("bookingTime") LocalDate bookingTime,
        @Param("startDate") LocalDate startDate,
        @Param("endDate") LocalDate endDate,
        @Param("user") User user
    );
    
    List<Booking> findByUserId(Long userId);
    
}