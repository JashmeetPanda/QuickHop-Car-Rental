package com.quickhop.repository;

import org.springframework.jdbc.core.RowMapper;
import com.quickhop.entity.User;
import java.sql.ResultSet;
import java.sql.SQLException;

public class UserRowMapper implements RowMapper<User> {

    @Override
    public User mapRow(ResultSet rs, int rowNum) throws SQLException {
        User user = new User();
        
        // Map the fields from the ResultSet to the User object
        user.setId(rs.getLong("id"));  // Map the ID field
        user.setUsername(rs.getString("username"));
        user.setEmail(rs.getString("email"));
        user.setPassword(rs.getString("password"));
        
        return user;
    }
}
