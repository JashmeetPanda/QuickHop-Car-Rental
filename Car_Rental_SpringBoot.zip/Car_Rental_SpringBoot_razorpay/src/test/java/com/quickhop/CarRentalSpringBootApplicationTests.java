package com.quickhop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CarRentalSpringBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
